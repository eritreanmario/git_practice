
package frc.robot;

public class FStickMap { 
    //Axis
    public static final int XAXIS = 0;
    public static final int YAXIS = 1;
    public static final int ROTATE = 2;
    public static final int SLIDER = 3;
    //Buttons
    public static final int TRIGGER = 1;
    public static final int B1 = 2;
    public static final int B2 = 3;
    public static final int B3 = 4;
    public static final int B4 = 5;
    public static final int B5 = 6;
    public static final int B6 = 7;
    public static final int B7 = 8;
    public static final int B8 = 9;
    public static final int B9 = 10;
    public static final int B10 = 11;
    public static final int B11 = 12;
    public static final int B12 = 13;
    public static final int B13 = 14;
    public static final int B14 = 15;
    public static final int B15 = 16;
    

}